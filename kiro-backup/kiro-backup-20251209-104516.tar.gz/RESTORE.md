# Kiro Configuration Restoration Guide

## Prerequisites

1. Install Kiro on the new system
2. Install required dependencies (Node.js, Git, etc.)
3. Have this backup directory available

## Restoration Steps

### 1. Restore User-Level Settings

```bash
# Create directory if it doesn't exist
mkdir -p ~/.kiro/settings

# Copy user settings
cp -r user-settings/* ~/.kiro/settings/
```

### 2. Clone Your Repositories

```bash
# Clone your project repositories
git clone <your-repo-url>
cd <your-repo>

# Workspace settings (.kiro/) should already be in the repo
# If not, restore them:
cp -r /path/to/backup/workspace-settings .kiro/settings
cp -r /path/to/backup/hooks .kiro/hooks
cp -r /path/to/backup/steering .kiro/steering
```

### 3. Update MCP Configurations

Edit `.kiro/settings/mcp.json` and update paths for the new system:

**Linux:**
```json
"args": ["/home/YOUR_USERNAME", "/home/YOUR_USERNAME/.kiro"]
```

**macOS:**
```json
"args": ["/Users/YOUR_USERNAME", "/Users/YOUR_USERNAME/.kiro"]
```

**Windows (WSL):**
```json
"args": ["C:\\Users\\YOUR_USERNAME", "C:\\Users\\YOUR_USERNAME\\.kiro"]
```

### 4. Verify Installation

1. Open Kiro
2. Open your workspace
3. Check MCP servers are connected (Kiro panel > MCP Servers)
4. Verify hooks are loaded (Explorer > Agent Hooks)
5. Test a simple command to ensure everything works

### 5. Troubleshooting

**MCP servers not connecting:**
- Check Node.js is installed: `node --version`
- Check npx is available: `npx --version`
- Manually reconnect from MCP panel

**Hooks not working:**
- Verify `.kiro/hooks/` directory exists
- Check hook JSON files are valid
- Restart Kiro

**Steering files not loading:**
- Verify `.kiro/steering/` directory exists
- Check markdown files are present
- Restart Kiro

## Platform-Specific Notes

### Moving from Windows to Linux/macOS

- Update all Windows paths (C:\Users\...) to Unix paths (/home/... or /Users/...)
- Line endings: Run `dos2unix` on config files if needed
- Shell commands: Update any Windows-specific commands in hooks

### Moving from Linux/macOS to Windows

- Update Unix paths to Windows paths
- Use WSL2 for better compatibility
- Update shell commands to PowerShell/cmd equivalents

## Verification Checklist

- [ ] Kiro installed and running
- [ ] User settings restored
- [ ] Workspace cloned/restored
- [ ] MCP servers connected
- [ ] Hooks visible in Explorer
- [ ] Steering files loaded
- [ ] Test command executed successfully

## Need Help?

Refer to KIRO_SETUP_DOCUMENTATION.md for complete configuration details.
